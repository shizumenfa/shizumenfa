 var user = prompt('请输入你的姓名：');
 if (user == '孟凡琦') {
     alert('啊，你就是孟凡小狗啊')
 } else {
     alert('你tm能把名打错了，小狗篮子')
 }
 var year = prompt('请输入你的出生年份：');
 var age = 2020 - year;
 if (age > 18 && age < 60) {
     alert('你个谎报年龄的小学生小垃圾')
 } else if (age <= 18 && age > 0) {
     alert('未成年给爷爬')
 } else if (age > 60) {
     alert('臭老头回家看孩子去')
 } else if (age <= 0) {
     alert('你TM是精子吗？')
 }

 /* var year = prompt('请输入查询年份');
 if (year % 4 == 0 && year % 100 !== 0 || year % 400 == 0) {
     alert(year + '是闰年')
 } else {
     alert(year + '是平年')
 } */